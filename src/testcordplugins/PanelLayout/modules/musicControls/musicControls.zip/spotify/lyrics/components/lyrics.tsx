/*
 * Vencord, a Discord client mod
 * Copyright (c) 2024 Vendicated and contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import { BaseText } from "@components/BaseText";
import { TooltipContainer } from "@components/TooltipContainer";
import { settings } from "@testcordplugins/PanelLayout/modules/musicControls/settings";
import { SpotifyLrcStore } from "@testcordplugins/PanelLayout/modules/musicControls/spotify/lyrics/providers/store";
import { useSpicyWordFrame } from "@testcordplugins/PanelLayout/modules/musicControls/spotify/lyrics/spicyAnimator/useSpicyWordFrame";
import { SpotifyStore } from "@testcordplugins/PanelLayout/modules/musicControls/spotify/SpotifyStore";
import { ContextMenuApi, openModalLazy, React, useEffect, useState, useStateFromStores } from "@webpack/common";

import { LyricsContextMenu } from "./ctxMenu";
import { LyricsModal } from "./modal";
import { cl, NoteSvg, useLyrics } from "./util";

const prevCl = cl("prev");
const nextCl = cl("next");
const currentCl = cl("current");

function LyricsDisplay({ scroll = true, style }: { scroll?: boolean; style?: React.CSSProperties; }) {
    const { showMusicNoteOnNoLyrics } = settings.use(["showMusicNoteOnNoLyrics"]);
    const { lyricsInfo, lyricRefs, currLrcIndex, isPlaying, positionRef } = useLyrics({ scroll });

    const currentLyrics = lyricsInfo?.lyricsVersions[lyricsInfo.useLyric] || null;
    const wordRefsRef = React.useRef<(HTMLSpanElement | null)[]>([]);

    const activeLineWords = currLrcIndex != null ? currentLyrics?.[currLrcIndex]?.words : undefined;

    useSpicyWordFrame(activeLineWords, wordRefsRef, () => positionRef.current, isPlaying);

    const makeClassName = (index: number): string => {
        if (currLrcIndex == null) return prevCl;

        const diff = index - currLrcIndex;

        if (diff === 0) return currentCl;
        return diff > 0 ? nextCl : prevCl;
    };

    return (
        <div
            className="vc-spotify-lyrics"
            style={style}
            onClick={() => openModalLazy(async () => props => <LyricsModal props={props} />)}
            onContextMenu={e => ContextMenuApi.openContextMenu(e, () => <LyricsContextMenu />)}
        >
            <div className="vc-spotify-lyrics-inner">
                {currentLyrics ? currentLyrics.map((line, i) => {
                    const isCurrentLine = currLrcIndex === i;
                    const hasWordTiming = isCurrentLine && !!line.words?.length;

                    return (
                        <div ref={lyricRefs[i]} key={i}>
                            <BaseText
                                size={isCurrentLine ? "sm" : "xs"}
                                className={makeClassName(i)}
                            >
                                {hasWordTiming
                                    ? line.words!.map((word, w) => (
                                        <React.Fragment key={w}>
                                            <span
                                                ref={(el: HTMLSpanElement | null) => { wordRefsRef.current[w] = el; }}
                                                className={word.IsPartOfWord ? "vc-spicy-word vc-spicy-part-of-word" : "vc-spicy-word"}
                                            >
                                                {word.text}
                                            </span>
                                            {word.IsPartOfWord ? "" : " "}
                                        </React.Fragment>
                                    ))
                                    : (line.text || NoteSvg())}
                            </BaseText>
                        </div>
                    );
                }) : showMusicNoteOnNoLyrics ? (
                    <TooltipContainer text="No synced lyrics found">
                        <NoteSvg />
                    </TooltipContainer>
                ) : null}
            </div>
        </div>
    );
}

export function SpotifyLyrics({ scroll = true }: { scroll?: boolean; } = {}) {
    SpotifyLrcStore.init();
    const track = useStateFromStores(
        [SpotifyStore],
        () => SpotifyStore.track,
        null,
        (prev, next) => (prev?.id ? prev.id === next?.id : prev?.name === next?.name)
    );

    const device = useStateFromStores(
        [SpotifyStore],
        () => SpotifyStore.device,
        null,
        (prev, next) => prev?.id === next?.id
    );

    const isPlaying = useStateFromStores([SpotifyStore], () => SpotifyStore.isPlaying);
    const [shouldHide, setShouldHide] = useState(false);

    useEffect(() => {
        setShouldHide(false);
        if (!isPlaying) {
            const timeout = setTimeout(() => setShouldHide(true), 1000 * 60 * 5);
            return () => clearTimeout(timeout);
        }
    }, [isPlaying]);

    if (!track || !device?.is_active || shouldHide) return null;

    const exportTrackImageStyle = {
        "--vc-spotify-track-image": `url(${track?.album?.image?.url || ""})`,
    } as React.CSSProperties;

    return <LyricsDisplay scroll={scroll} style={exportTrackImageStyle} />;
}
